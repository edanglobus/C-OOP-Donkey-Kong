#pragma once

#include <windows.h>

void gotoxy(int x, int y);
void ShowConsoleCursor(bool showFlag);
int random39Or42();