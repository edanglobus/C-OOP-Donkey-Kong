#include "ghost.h"

Mario* Ghost::mario_ptr = nullptr;


